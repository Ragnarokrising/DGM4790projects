<footer>
	<p>&copy Vickys Paws and Biscuits< | 2018 | 800-123-1234 | <a href="/admin">Admin</a></p>
</footer>