@extends ('layout')

@section('content')
 
<h1>Welcome Member!</h1>

<p>Click shop above to see what we have!</p>

@endsection