<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Smartform extends Model
{
    protected $table = 'smartform';
    public $timestamps = false;
}
